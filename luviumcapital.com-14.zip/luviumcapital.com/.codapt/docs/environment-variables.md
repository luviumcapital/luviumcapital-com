Environment variables must be added to the Zod schema in `src/server/env.ts`, and defined in `.env`.

Environment variables are only available to server-side code.
